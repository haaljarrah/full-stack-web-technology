var reservations = []; //E.g., { plate: '21-12345', brand: 'Mercedes', slot: 'A3' }

var active = {};

function refresh_grid() {
    var divGrid = document.getElementById('divGrid');

    divGrid.innerHTML = '';

    if (reservations.length === 0) {
        var divColumn = document.createElement('div');
        var divNoReservations = document.createElement('div');

        divColumn.className = 'col mt-3';
        divNoReservations.className = 'alert alert-warning';

        divNoReservations.appendChild(document.createTextNode('No Cars'));
        divColumn.appendChild(divNoReservations);

        divGrid.appendChild(divColumn);
    }
    else {
        for (var i = 0; i < reservations.length; i++) {
            var reservation = reservations[i];

            var divReservation = document.createElement('div');
            var divCard = document.createElement('div');
            var divCardBody = document.createElement('div');
            var imgCar= document.createElement('img');
            var hCarPlate = document.createElement('h4');
            var hParkingSlot = document.createElement('h6');
            var btnUpdate = document.createElement('button');
            var btnExit = document.createElement('button');
            var btnCancel = document.createElement('button');

            divReservation.className = 'col-sm-6 col-md-6 col-lg-4 mt-3';
            divCard.className = 'card h-100 p-3';
            divCardBody.className = 'card-body';
            imgCar.className = 'card-img-top';
            hCarPlate.className = 'card-title text-primary';
            hParkingSlot.className = 'card-subtitle mb-2 text-muted';
            btnUpdate.className = 'btn btn-sm btn-primary me-1';
            btnExit.className = 'btn btn-sm btn-success me-1';
            btnCancel.className = 'btn btn-sm btn-danger me-1';

            if (reservation.brand === 'Mercedes') {
                imgCar.src = 'images/mercedes.jpg';
            }
            else if (reservation.brand === 'BMW') {
                imgCar.src = 'images/bmw.jpg';
            }
            else if (reservation.brand === 'Toyota') {
                imgCar.src = 'images/toyota.jpg';
            }
            else if (reservation.brand === 'Audi') {
                imgCar.src = 'images/audi.jpg';
            }
            else if (reservation.brand === 'Lexus') {
                imgCar.src = 'images/lexus.jpg';
            }
            else {
                imgCar.className = 'd-none';
            }

            hCarPlate.appendChild(document.createTextNode(`${reservation.plate}`));
            hParkingSlot.appendChild(document.createTextNode(`Parking Slot: ${reservation.slot}`));
            btnUpdate.appendChild(document.createTextNode('Update'));
            btnExit.appendChild(document.createTextNode('Exit'));
            btnCancel.appendChild(document.createTextNode('Cancel'));

            btnUpdate.setAttribute('data-index', i);
            btnExit.setAttribute('data-index', i);
            btnCancel.setAttribute('data-index', i);

            btnUpdate.onclick = (sender) => {
                update(parseInt(sender.target.getAttribute('data-index')));
            };

            btnExit.onclick = (sender) => {
                exit(parseInt(sender.target.getAttribute('data-index')));
            };

            btnCancel.onclick = (sender) => {
                cancel(parseInt(sender.target.getAttribute('data-index')));
            };

            //
            //
            //
            divCardBody.appendChild(hCarPlate);
            divCardBody.appendChild(hParkingSlot);
            divCardBody.appendChild(btnUpdate);
            divCardBody.appendChild(btnExit);
            divCardBody.appendChild(btnCancel);

            divCard.appendChild(imgCar);
            divCard.appendChild(divCardBody);

            divReservation.appendChild(divCard);

            divGrid.appendChild(divReservation);
        }
    }
}

function refresh_form() {
    var inputCarPlate = document.getElementById('inputCarPlate');
    var selectCarBrand = document.getElementById('selectCarBrand');
    var selectParkingSlot = document.getElementById('selectParkingSlot');

    inputCarPlate.value = active.plate;
    selectCarBrand.value = active.brand;
    selectParkingSlot.value = active.slot;
}

function update(index) {
    let reservation = reservations[index];

    active = { plate: reservation.plate, brand: reservation.brand, slot: reservation.slot };

    this.refresh_form();
}

//
//YOU WILL BE RESPONSIBLE FOR IMPLEMENTING THE FOLLOWING FUNCTIONS
//
window.onload = () => {
    refresh_data();
};

function refresh_car(){
    
    var req = new XMLHttpRequest();


    req.onload = function() {
        let item = JSON.parse(this.responseText);

        reservations = item;

        refresh_data();
        
    };

    req.open('GET','http://localhost:8787/reservations');
    req.send();

}
function refresh_data() {
    //
    
    var inputCarPlate = document.getElementById('inputCarPlate');
    var inputCarBrand = document.getElementById('selectCarBrand');
    var inputParkingSolt = document.getElementById('selectParkingSlot');

    inputCarPlate.value = active.plate;
    inputCarBrand.value = active.brand;
    inputParkingSolt.value = active.slot;

    //WRITE YOUR CODE THAT CALLS THE GET ALL PENDING RESERVATIONS (STATUS = 1) WEB SERVICE
}

function save() {
    var inputCarPlate = document.getElementById('inputCarPlate');
    var selectCarBrand = document.getElementById('selectCarBrand');
    var selectParkingSlot = document.getElementById('selectParkingSlot');

    if (!inputCarPlate.value) return;
    if (!selectCarBrand.value) return;
    if (!selectParkingSlot.value) return;


    var obj = { plate: inputCarPlate.value, brand: selectCarBrand.value, slot: selectParkingSlot.value };

    //
    refresh_car();
    //WRITE YOUR CODE THAT CALLS THE CREATE OR UPDATE WEB SERVICE
   

}

function exit(index) {
    if (window.confirm('Are you sure?')) {
        //
        
      
        //WRITE YOUR CODE THAT CALLS THE FINISH WEB SERVICE
    }
}

function cancel(index) {
    if (window.confirm('Are you sure?')) {
        //
        reservations.splice(index, 1);
        refresh_table(); 

        //WRITE YOUR CODE THAT CALLS THE DELETE WEB SERVICE
    }
}
//
//END YOU WILL BE RESPONSIBLE FOR IMPLEMENTING THE FOLLOWING FUNCTIONS
//