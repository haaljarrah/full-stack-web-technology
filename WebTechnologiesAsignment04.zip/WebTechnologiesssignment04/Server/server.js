
var express = require('express');
var cors = require('cors');
var sqlite = require('sqlite3');

//Do not forget to install the packages: express, cors, and sqlite3 (E.g., npm install express)

var app = express();

app.use(express.json());
app.use(cors());

//
//The database contains one table: orders_info
//The table is composed of 5 columns: plate, brand, slot, and status
//
var db = new sqlite.Database('./parking.db', (error) => {
    if (error) {
        console.log('Error in connecting to db: ' + JSON.stringify(error));
    }
    else {
        console.log('Connected to db successfully');
    }
});

//
//YOU WILL BE RESPONSIBLE FOR WRITING THIS CODE
//

//1.0
//Implement a web service that returns all pending reservations. Pending reservations have the status 1
//The route for the web service shall be GET '/reservations'
//The database table is composed of 4 columns: plate, brand, slot, and status
app.get('/reservations', function (req, res) {
    db.all('SELECT * FROM reservations WHERE status = 1;', function(error, rows) {
        if (error) {
            res.send('Error in database');
        }
        else {
            res.send(rows);
        }
    });
});

//2.0
//Implement a web service that creates a new reservation. Status for new reservation shall be 1 (Pending)
//The route for the web service shall be POST '/reservations'
//The client shall send the reservation data in the request body
//The database table is composed of 4 columns: plate, brand, slot, and status
app.post('/reservation', function (req, res) {
    var reservation = req.body;

    db.run('INSERT INTO reservation (plate, brand, slot, status) VALUES (?, ?, ?, 1);', [reservation.plate, reservation.brand, reservation.slot], function(error) {
        if (error) {
            res.send('Error in database: ' + JSON.stringify(error));
        }
        else {
            res.send();
        }
    });
});

//3.0
//Implement a web service that updates an existing reservation where slot can only be updated
//The route for the web service shall be POST '/reservations/:plate'
//The client shall send the reservation data in the request body
//The database table is composed of 4 columns: plate, brand, slot, and status
app.post('/reservations/:plate', function (req, res) {
    var reservation = req.body;

    db.run('UPDATE reservation SET slot = ? WHERE plate = ?;', [reservation.slot, req.params.plate], function(error) {
        if (error) {
            res.send('Error in database: ' + JSON.stringify(error));
        }
        else {
            res.send();
        }
    });
});
//4.0
//Implement a web service that updates the status of an existing reservation to 2 (Exited)
//The route for the web service shall be POST '/reservations/:plate/exit'
//The client shall NOT send data in the request body
//The database table is composed of 4 columns: plate, brand, slot, and status
app.post('/reservations/:plate/exit', function (req, res) {
    var reservation = req.body;

    db.run('UPDATE reservation SET slot = 2 WHERE plate = ?;', [req.params.plate], function(error) {
        if (error) {
            res.send('Error in database: ' + JSON.stringify(error));
        }
        else {
            res.send();
        }
    });
});
//5.0
//Implement a web service that deletes an existing reservation
//The route for the web service shall be DELETE '/reservations/:plate'
app.delete('/reservations/:plate', function (req, res) {
    db.run('DELETE FROM reservations WHERE number = ?', [req.params.plate], function(error) {
        if (error) {
            res.send('Error in database');
        }
        else {
            res.send();
        }
    });
});
//
//END YOU WILL BE RESPONSIBLE FOR WRITING THIS CODE
//

app.listen(8787, function() {
    console.log('Server listening at http://127.0.0.1:8787');
});
